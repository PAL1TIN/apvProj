namespace SistemaEstoque
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProd prod = new FrmProd();
            prod.MdiParent = this;
            prod.Show();
        }

        private void funcionarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFunc func = new FrmFunc();
            func.MdiParent = this;
            func.Show();
        }
    }
}
