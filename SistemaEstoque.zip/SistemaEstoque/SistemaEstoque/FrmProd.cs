﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaEstoque
{
    public partial class FrmProd : Form
    {
        public FrmProd()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Boolean salvo;
            String nome, descricao;
            int qtd;

            nome = txtNome.Text;
            descricao = txtDescricao.Text;
            qtd = int.Parse(txtQuantidade.Text);
            MessageBox.Show("INFO: " + nome +"\n"+ descricao + "\n" + qtd);
        }
    }
}
