﻿namespace SistemaEstoque
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuAplicacao = new MenuStrip();
            pToolStripMenuItem = new ToolStripMenuItem();
            funcionarioToolStripMenuItem = new ToolStripMenuItem();
            menuAplicacao.SuspendLayout();
            SuspendLayout();
            // 
            // menuAplicacao
            // 
            menuAplicacao.Items.AddRange(new ToolStripItem[] { pToolStripMenuItem, funcionarioToolStripMenuItem });
            menuAplicacao.Location = new Point(0, 0);
            menuAplicacao.Name = "menuAplicacao";
            menuAplicacao.Size = new Size(800, 24);
            menuAplicacao.TabIndex = 1;
            menuAplicacao.Text = "menuStrip";
            // 
            // pToolStripMenuItem
            // 
            pToolStripMenuItem.Name = "pToolStripMenuItem";
            pToolStripMenuItem.Size = new Size(62, 20);
            pToolStripMenuItem.Text = "Produto";
            pToolStripMenuItem.Click += pToolStripMenuItem_Click;
            // 
            // funcionarioToolStripMenuItem
            // 
            funcionarioToolStripMenuItem.Name = "funcionarioToolStripMenuItem";
            funcionarioToolStripMenuItem.Size = new Size(82, 20);
            funcionarioToolStripMenuItem.Text = "Funcionario";
            funcionarioToolStripMenuItem.Click += funcionarioToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuAplicacao);
            IsMdiContainer = true;
            MainMenuStrip = menuAplicacao;
            Name = "Form1";
            Text = "Formulario Pai";
            WindowState = FormWindowState.Maximized;
            menuAplicacao.ResumeLayout(false);
            menuAplicacao.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuAplicacao;
        private ToolStripMenuItem pToolStripMenuItem;
        private ToolStripMenuItem funcionarioToolStripMenuItem;
    }
}
